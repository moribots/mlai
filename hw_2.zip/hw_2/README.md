# Machine Learning & Artificial Intelligence, ME 469
## Homework 2, Part A
### Maurice Rahme
### Student ID: 3219435

### Locally Weighted Linear Regression for Motion Model Estimation
### Data Set: ds0

****
The 'gt_train.csv file contains the columns: timestamp[s], x[m], y[m], theta[rad], and the 'odom_train.csv' contains the columns: timestamp[s], v[m/s], w[rad/s]. The 'odom_dt.csv' file contains the columns: timestamp[s], vdt[m], wdt[rad].

You will need to close all displayed plots before moving on to the next section. I chose to do this because the run-time is very slow, and getting some plots gradually is a better experience than having to wait around 30 minutes for all the plots.