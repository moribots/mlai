# Machine Learning & Artificial Intelligence, ME 469
## Homework 2, Part A
### Maurice Rahme
### Student ID: 3219435

### Locally Weighted Linear Regression for Motion Model Estimation
### Data Set: ds0

****
The 'gt_train.csv file contains the columns: timestamp[s], x[m], y[m], theta[rad], and the 'odom_train.csv' contains the columns: timestamp[s], v[m/s], w[rad/s]. The 'odom_dt.csv' file contains the columns: timestamp[s], vdt[m], wdt[rad].